﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.Sql;
using System.Data.SqlClient;

namespace PDisaster0030482321003
{
    public partial class frmPrincipal : Form
    {
        public static SqlConnection conexao;
        public frmPrincipal()
        {
            InitializeComponent();
        }

        private void frmPrincipal_Load(object sender, EventArgs e)
        {
            try
            {
                // aqui a conexão vai depender da máquina
                conexao = new SqlConnection("Data Source=Apolo;Initial Catalog=LP2;User ID=BD2321003; Password= @pmn1992;Encrypt=False");
                conexao.Open();
            }
            catch (SqlException ex)
            {
                MessageBox.Show($"Erro de banco de dados, favor corrigir =/{ex.Message}");
            }           
            
            catch (Exception ex)
            {
                MessageBox.Show($"Outros erros favor ir reclamar no Procon =/ {ex.Message}");
            }
        }

        private void outrosEventosToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if(Application.OpenForms.OfType<FormTipo>().Count() > 0) 
            {
                Application.OpenForms["FormTipo"].BringToFront();
            }
            else 
            { 
                FormTipo objfrm2 = new FormTipo();
                objfrm2.MdiParent = this;
                objfrm2.WindowState = FormWindowState.Maximized;
                objfrm2.BackColor = Color.Cyan;
                objfrm2.FormBorderStyle = FormBorderStyle.Fixed3D;
                objfrm2.ShowInTaskbar = false;
                objfrm2.Show();
            }
        }

        private void outrasCidadesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<FormCidade>().Count() > 0)
            {
                Application.OpenForms["FormCidade"].BringToFront();
            }
            else
            {
                FormCidade objfrm2 = new FormCidade();
                objfrm2.MdiParent = this;
                objfrm2.WindowState = FormWindowState.Maximized;
                objfrm2.BackColor = Color.Cyan;
                objfrm2.FormBorderStyle = FormBorderStyle.Fixed3D;
                objfrm2.ShowInTaskbar = false;
                objfrm2.Show();
            }
        }
    }
}

﻿using PDisaster0030482321003;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Text;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PDisaster0030482321003
{
    public partial class FormEvento : Form
    {
        private BindingSource bnEvento = new BindingSource();
        private bool bInclusao = false;
        private DataSet dsEvento = new DataSet();
        private DataSet dsTipo = new DataSet();
        private DataSet dsCidade = new DataSet();

        public FormEvento()
        {
            InitializeComponent();
        }

        private void FormEvento_Load(object sender, EventArgs e)
        {
            try
            {
                Evento Event = new Evento();
                dsEvento.Tables.Add(Event.Listar());
                bnEvento.DataSource = dsEvento.Tables["Evento"];
                dgvEvento.DataSource = bnEvento;
                bnvEvento.BindingSource = bnEvento;

                txtIdEvento.DataBindings.Add("TEXT", bnEvento, "idEvento");
                cbxSeveridade.DataBindings.Add("SelectedItem", bnEvento, "nivelSeveridade");
                mskbxAreaAfetada.DataBindings.Add("TEXT", bnEvento, "areafetada");
                mskbxPopulacao.DataBindings.Add("TEXT", bnEvento, "populacaoafetada");
                txtObservacao.DataBindings.Add("TEXT", bnEvento, "observacao");
                dtpDataOcorrencia.DataBindings.Add("TEXT", bnEvento, "dataocorrencia");

                Cidade Cid = new Cidade();
                dsCidade.Tables.Add(Cid.Listar());
                cbxCidade.DataSource = dsCidade.Tables["Cidade"];
                cbxCidade.DisplayMember = "nome";
                cbxCidade.ValueMember = "idcidade";
                cbxCidade.DataBindings.Add("SelectedValue", bnEvento, "cidade_idcidade");


                Tipo Tip = new Tipo();
                dsTipo.Tables.Add(Tip.Listar());
                cbxTipo.DataSource = dsTipo.Tables["tipo"];
                cbxTipo.DisplayMember = "descricao";
                cbxTipo.ValueMember = "idtipo";
                cbxTipo.DataBindings.Add("SelectedValue", bnEvento, "tipo_idtipo");
            }

            catch (Exception ex)
            { MessageBox.Show(ex.Message); }
        }

        private void btnNovo_Click(object sender, EventArgs e)
        {
            if (tbEvento.SelectedIndex == 0)
            {
                tbEvento.SelectTab(1);
            }
            bnEvento.AddNew();

            
            cbxCidade.Enabled = true;
            cbxTipo.Enabled = true;
            cbxCidade.SelectedIndex = 0;
            cbxTipo.SelectedIndex = 0;
            cbxSeveridade.Enabled = true;
            cbxSeveridade.SelectedIndex = 0;
            mskbxAreaAfetada.Enabled = true;
            mskbxPopulacao.Enabled = true;
            txtObservacao.Enabled = true;
            dtpDataOcorrencia.Enabled = true;

            cbxTipo.Focus();

            btnSalvar.Enabled = true;
            btnAlterar.Enabled = false;
            btnNovo.Enabled = false;
            btnExcluir.Enabled = false;
            btnCancelar.Enabled = true;
            bInclusao = true;

            cbxCidade.Focus();

            btnSalvar.Enabled = true;
            btnAlterar.Enabled = false;
            btnNovo.Enabled = false;
            btnExcluir.Enabled = false;
            btnCancelar.Enabled = true;
            bInclusao = true;

        }

        private void btnAlterar_Click(object sender, EventArgs e)
        {
            if (tbEvento.SelectedIndex == 0)
            {
                tbEvento.SelectTab(1);
            }
            cbxCidade.Enabled = true;
            cbxTipo.Enabled = true;
            cbxCidade.SelectedIndex = 0;
            cbxTipo.SelectedIndex = 0;
            cbxSeveridade.Enabled = true;
            cbxSeveridade.SelectedIndex = 0;
            mskbxAreaAfetada.Enabled = true;
            mskbxPopulacao.Enabled = true;
            txtObservacao.Enabled = true;
            dtpDataOcorrencia.Enabled = true;

            cbxTipo.Focus();

            btnSalvar.Enabled = true;
            btnAlterar.Enabled = false;
            btnNovo.Enabled = false;
            btnExcluir.Enabled = false;
            btnCancelar.Enabled = true;
            bInclusao = true;


            cbxCidade.Focus();

            btnSalvar.Enabled = true;
            btnAlterar.Enabled = false;
            btnNovo.Enabled = false;
            btnExcluir.Enabled = false;
            btnCancelar.Enabled = true;
            bInclusao = true;
        }

        private void btnSalvar_Click(object sender, EventArgs e)
        {

        }

        private void btnExcluir_Click(object sender, EventArgs e)
        {
            if (tbEvento.SelectedIndex == 0)
            {
                tbEvento.SelectTab(1);
            }

            if (MessageBox.Show("Confirmar a exclusão", " Sim ou Não", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) == DialogResult.Yes)

            {
                Evento RegEvento = new Evento();

                RegEvento.IdEventos = Convert.ToInt16(txtIdEvento.Text);

                if (RegEvento.Excluir() > 0)

                {
                    MessageBox.Show("Evento excluído com sucesso");
                    Evento R = new Evento();
                    dsEvento.Tables.Clear();
                    dsEvento.Tables.Add(R.Listar());
                    bnEvento.DataSource = dsEvento.Tables["Evento"];
                }
                else
                {
                    MessageBox.Show("Erro ao excluir Evento!");
                }

            }
        }

        private void btnCancelar_Click(object sender, EventArgs e)
        {

        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}

private void btnSalvar_Click(object sender, EventArgs e)
{
    if (txtDescricao.Text == "")
    {
        MessageBox.Show("Descrição invalida");
    }
    else
    {
        Evento RegEvent = new Evento();
        RegEvento.Descricao = txtDescricao.Text;

        if (bInclusao)
        {
            if (RegEvento.Incluir() > 0)
            {
                MessageBox.Show("Evento adicionado com sucesso!");

                txtDescricao.Enabled = false;
                btnSalvar.Enabled = false;
                btnAlterar.Enabled = true;
                btnNovo.Enabled = true;
                btnExcluir.Enabled = true;
                btnCancelar.Enabled = false;

                btnInclusao.Enabled = false;

                dsEvento.Tables.Clear();
                dsEvento.Tables.Add(RegEvento.Listar());
                bnEvento.DataSource = dsEvento.Tables["Evento"];
            }
            else
            {
                MessageBox.Show("Erro ao gravar Evento");
            }
        }
        else
        {
            RegEvento.IdEvento = Convert.ToInt32(txtIdEvento.Text);
        }
        if (RegEvento.Alterar() > 0)
        {
            MessageBox.Show("Evento alterado com Sucesso!");
            txtDescricao.Enabled = false;
            btnSalvar.Enabled = false;
            btnAlterar.Enabled = true;
            btnNovo.Enabled = true;
            btnExcluir.Enabled = true;
            btnCancelar.Enabled = false;

            btnInclusao.Enabled = false;

            dsEvento.Tables.Clear();
            dsEvento.Tables.Add(RegEvento.Listar());
            bnEvento.DataSource = dsEvento.Tables["Evento"];
        }
        else { MessageBox.Show("Erro ao alterar"); }
    }
}

private void btnCancelar_Click(object sender, EventArgs e)
{
    bnEvento.CancelEdit();
    txtDescricao.Enabled = false;
    btnSalvar.Enabled = false;
    btnAlterar.Enabled = true;
    btnNovo.Enabled = true;
    btnExcluir.Enabled = true;
    btnCancelar.Enabled = false;
    btnInclusao.Enabled = false;
}

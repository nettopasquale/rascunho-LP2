﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.Sql;
using System.Data.SqlClient;


namespace PDisaster0030482321003
{
    internal class Evento
    {
        public int IdEventos { get; set; }
        public int Tipo_IdTipo { get; set; }
        public int Cidade_IDCidade { get; set; }
        public char NivelSeveridade { get; set; }
        public int AreaAfetada { get; set; }
        public int PessoasAfetadas { get; set; }
        public string Observacao { get; set; }
        public DateTime DataOcorrrencia { get; set; }

        public DataTable Listar()
        {
            SqlDataAdapter daEvento;
            DataTable dtEvento = new DataTable();
            try
            {
                daEvento = new SqlDataAdapter("SELECT * FROM Evento ORDER BY IDEVENTO", frmPrincipal.conexao);
                daEvento.Fill(dtEvento);
                daEvento.FillSchema(dtEvento, SchemaType.Source);
            }
            catch (Exception)
            {
                throw;
            }
            return dtEvento;
        }
        public int Incluir()
        {
            int retorno = 0;

            try
            {
                SqlCommand mycommand;
                mycommand = new SqlCommand("INSERT INTO Evento VALUES " + "C@IDTIPO, @IDCIDADE, @NIVELSEVERIDADE, @AREAAFETADA,@PESSOASAFETADAS,@OBSERVACAO,@DATAOCORRENCIA", frmPrincipal.conexao);

                mycommand.Parameters.Add(new SqlParameter("@IDTIPO", SqlDbType.Int));
                mycommand.Parameters.Add(new SqlParameter("@IDCIDADE", SqlDbType.Int));
                mycommand.Parameters.Add(new SqlParameter("@NIVELSEVERIDADE", SqlDbType.Char));
                mycommand.Parameters.Add(new SqlParameter("@AREAAFETADA", SqlDbType.Int));
                mycommand.Parameters.Add(new SqlParameter("@PESSOASAFETADAS", SqlDbType.Int));
                mycommand.Parameters.Add(new SqlParameter("@OBSERVACAO", SqlDbType.VarChar));
                mycommand.Parameters.Add(new SqlParameter("@DATAOCORRENCIA", SqlDbType.DateTime));

                mycommand.Parameters["@IDTIPO"].Value = Tipo_IdTipo;
                mycommand.Parameters["@IDCIDADE"].Value = Cidade_IDCidade;
                mycommand.Parameters["@AREAAFETADA"].Value = AreaAfetada;
                mycommand.Parameters["@PESSOASAFETADAS"].Value = PessoasAfetadas;
                mycommand.Parameters["@OBSERVACAO"].Value = Observacao;
                mycommand.Parameters["@DATAOCORRENCIA"].Value = DataOcorrrencia;


                retorno = mycommand.ExecuteNonQuery();
            }
            catch (Exception)
            {
                throw;
            }
            return retorno;
        }
            public int Alterar()
            {
                int retorno = 0;

                try
                {
                    SqlCommand myCommand;
                myCommand = new SqlCommand("UPDATE Evento SET TIPO_IDTIPO = @IDTIPO,CIDADE_IDCIDADE=@IDCIDADE, NIVELSEVERIDADE=@NIVELSEVERIDADE, AREAAFETADA = @AREAAFETADA, PESSOASAFETADAS=@PESSOASAFETADAS, OBSERVACAO=@ORBSERVACAO, DATAOCORRENCIA=@DATAOCORRENCIA WHERE IDEVENTO = @IDEVENTO", frmPrincipal.conexao);



                    myCommand.Parameters.Add(new SqlParameter("@IDEVENTO", SqlDbType.Int));
                    myCommand.Parameters.Add(new SqlParameter("@IDTIPO", SqlDbType.Int));
                    myCommand.Parameters.Add(new SqlParameter("@IDCIDADE", SqlDbType.Int));
                    myCommand.Parameters.Add(new SqlParameter("@NIVELSEVERIDADE", SqlDbType.Char));
                    myCommand.Parameters.Add(new SqlParameter("@AREAAFETADA", SqlDbType.Int));
                    myCommand.Parameters.Add(new SqlParameter("@PESSOASAFETADAS", SqlDbType.Int));
                    myCommand.Parameters.Add(new SqlParameter("@OBSERVACAO", SqlDbType.VarChar));
                    myCommand.Parameters.Add(new SqlParameter("@DATAOCORRENCIA", SqlDbType.DateTime));

                    myCommand.Parameters["@IDEVENTO"].Value = IdEventos;
                    myCommand.Parameters["@IDTIPO"].Value = Tipo_IdTipo;
                    myCommand.Parameters["@IDCIDADE"].Value = Cidade_IDCidade;
                    myCommand.Parameters["@NIVELSEVERIDADE"].Value = NivelSeveridade;
                    myCommand.Parameters["@AREAAFETADA"].Value = AreaAfetada;
                    myCommand.Parameters["@PESSOASAFETADAS"].Value = PessoasAfetadas;
                    myCommand.Parameters["@OBSERVACAO"].Value = Observacao;
                    myCommand.Parameters["@DATAOCORRENCIA"].Value = DataOcorrrencia;

                    retorno = myCommand.ExecuteNonQuery();
                }
                catch (Exception) { throw; }
                return retorno;
            }
        public int Excluir()
        {
            int nReg = 0;
            try
            {
                SqlCommand myCommand;

                myCommand = new SqlCommand("DELETE FROR Evento WHERE IDEvento = @IDEvento", frmPrincipal.conexao);

                myCommand.Parameters.Add(new SqlParameter("@IDEvento", SqlDbType.Int));
                myCommand.Parameters["@IDEvento"].Value = IdEventos;

                nReg = myCommand.ExecuteNonQuery();
            }
            catch (Exception) { throw; }

            return nReg;
        }


    }
}
